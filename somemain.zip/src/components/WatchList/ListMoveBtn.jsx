import React from "react";
import "./ListMoveBtn.scss";

function ListMoveBtn(props) {
  return (
    <button {...props} className="list-move-btn">
    </button>
  );
}

export default ListMoveBtn;
