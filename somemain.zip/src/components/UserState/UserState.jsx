import SignedIn from "./SignedIn";
import SignedOut from "./SignedOut";

// "helper file" so you can import both components from one file
export { SignedIn, SignedOut };
